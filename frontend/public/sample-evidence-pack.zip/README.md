# Evidence Pack

Task: `tc-20260415-sample01`
Agent: `security-audit-v1` (version 2, risk class `limited`)
Generated at: 2026-04-21T16:21:49.983312+00:00

This bundle contains the per-execution compliance artefacts required by the
EU AI Act (Regulation 2024/1689). It is intended for handover to auditors,
market surveillance authorities, or internal compliance reviews.

## Contents

| File | Purpose | Article |
|---|---|---|
| `manifest.json` | Machine-readable index of the pack | - |
| `README.md` | This document | - |
| `output/` | Raw agent outputs, including Art. 50 disclosure block | Art. 13 |
| `event_log.json` | Immutable event log for this task | Art. 12 / 19 |
| `capability_card.json` | Agent capability card with Ed25519 signature | Art. 13 |
| `provenance.json` | Machine-readable AI-generated content marker | Art. 50 |
| `execution.json` | Execution lifecycle (start, end, server, metrics) | Art. 12 |
| `task.json` | Task contract (inputs, constraints, status) | Art. 12 |

## Verification

1. Check the capability card signature against the provider's public key.
2. Cross-reference `provenance.json` with the `X-AI-Provenance` header
   returned by the `/v1/tasks/tc-20260415-sample01/result` endpoint.
3. Confirm the event log covers the full lifecycle from creation to completion.

This pack is one of several compliance artefacts. Technical documentation
(Annex IV), the Quality Management System (Art. 17), and the risk management
system (Art. 9) are maintained separately and retained for 10 years under
Art. 18.
